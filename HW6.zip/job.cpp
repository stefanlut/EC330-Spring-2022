#include "job.h"
#include <vector>

using namespace std;

bool canFinish(int n, vector<pair<int, int>> &dependencies) { return false; }

bool canRun(int n, vector<pair<int, int>> &dependencies, int j, int i) {
  return false;
}
