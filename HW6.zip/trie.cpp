#include <string>
#include "trie.h"

using namespace std;

void Trie::insert(string key, int val) {
}

int Trie::search(string key) {
    return 0;
}

void Trie::remove(string key) {
}
